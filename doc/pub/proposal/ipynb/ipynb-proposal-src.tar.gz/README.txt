This IPython notebook proposal.ipynb does not require any additional
programs.
