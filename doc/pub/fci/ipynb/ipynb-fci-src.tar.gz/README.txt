This IPython notebook fci.ipynb does not require any additional
programs.
